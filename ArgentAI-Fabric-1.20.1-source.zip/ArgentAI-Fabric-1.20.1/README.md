# ArgentAI — Fabric 1.20.1

A Fabric mod project for Minecraft Java Edition 1.20.1. It is a Java mod project (not an Android app).

## Current prototype features
- Gives each player an ArgentAI Chat Controller and ArgentAI Spawn Egg on their first join.
- Right-click the controller to open the in-game prompt screen.
- Sends prompts to Groq from the logical server.
- Parses a constrained JSON block plan and places up to 128 blocks within a 16-block offset limit, only where the target block is replaceable and the player may build.
- Spawn egg creates a humanoid-shaped ArgentAI companion using the vanilla player model; it wanders and looks at nearby players.
- `/skin steve` and `/skin alex` change the companion's default Steve/Alex-style skin variant (nearby within 32 blocks).

## Important limitations
This is an early prototype, not the full autonomous agent requested. The companion currently wanders and looks at players; it does not yet navigate to build sites or execute tasks itself. The `/skin` command selects vanilla default Steve/Alex appearance, not arbitrary uploaded skin URLs/usernames. Building is limited to 128 simple block placements per AI response. No arbitrary file access or command execution is exposed to the AI.

## Groq setup
1. Start the game once with the mod installed.
2. Edit `config/argentai.json` and set `apiKey` to a newly generated Groq key.
3. Restart the world/server.

Never publish your API key or commit `config/argentai.json` to a public repository. The key previously pasted into chat should be revoked and replaced.

## Build
Requires JDK 17 and Gradle 8.6. From this project directory:

```bash
gradle build
```

The mod JAR is generated in `build/libs/argentai-1.0.0.jar`.

### Build online without installing Java locally
Upload this project to a GitHub repository. The included GitHub Actions workflow builds it on GitHub: open **Actions → Build ArgentAI Fabric 1.20.1 → Run workflow**, then download the `ArgentAI-Fabric-1.20.1` artifact from the completed run.

## Install
Install Fabric Loader for Minecraft 1.20.1 and matching Fabric API. Put `argentai-1.0.0.jar` in `.minecraft/mods/`.
