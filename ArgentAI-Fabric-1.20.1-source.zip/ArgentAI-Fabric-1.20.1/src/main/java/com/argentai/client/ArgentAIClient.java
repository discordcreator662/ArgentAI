package com.argentai.client;

import com.argentai.ArgentAI;
import com.argentai.entity.ArgentEntity;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.fabricmc.fabric.api.event.player.UseItemCallback;
import com.argentai.item.ArgentItems;
import net.minecraft.util.ActionResult;
import net.minecraft.client.MinecraftClient;
import java.util.UUID;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.entity.MobEntityRenderer;
import net.minecraft.client.render.entity.model.EntityModelLayers;
import net.minecraft.client.render.entity.model.PlayerEntityModel;
import net.minecraft.client.util.DefaultSkinHelper;
import net.minecraft.util.Identifier;

public class ArgentAIClient implements ClientModInitializer {
    @Override public void onInitializeClient() {
        EntityRendererRegistry.register(ArgentAI.ARGENT_ENTITY, ArgentPlayerRenderer::new);
        UseItemCallback.EVENT.register((player, world, hand) -> {
            if (world.isClient && player.getStackInHand(hand).isOf(ArgentItems.AI_CONTROLLER)) {
                MinecraftClient.getInstance().setScreen(new ArgentChatScreen());
                return ActionResult.success(true);
            }
            return ActionResult.PASS;
        });
    }
    private static class ArgentPlayerRenderer extends MobEntityRenderer<ArgentEntity, PlayerEntityModel<ArgentEntity>> {
        ArgentPlayerRenderer(EntityRendererFactory.Context context) {
            super(context, new PlayerEntityModel<>(context.getPart(EntityModelLayers.PLAYER), false), 0.5f);
        }
        @Override public Identifier getTexture(ArgentEntity entity) { return DefaultSkinHelper.getTexture(new UUID(0L, entity.isAlexSkin() ? 1L : 0L)); }
    }
}
