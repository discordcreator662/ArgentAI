package com.argentai.client;

import com.argentai.network.ArgentNetworking;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.text.Text;
import net.minecraft.util.PacketByteBufs;

public class ArgentChatScreen extends Screen {
    private TextFieldWidget input;
    public ArgentChatScreen() { super(Text.literal("ArgentAI")); }
    @Override protected void init() {
        input = new TextFieldWidget(textRenderer, width / 2 - 145, height / 2 - 8, 290, 20, Text.literal("Ask ArgentAI"));
        input.setMaxLength(512); addDrawableChild(input); setInitialFocus(input);
        addDrawableChild(ButtonWidget.builder(Text.literal("Send"), b -> send()).dimensions(width / 2 - 45, height / 2 + 22, 90, 20).build());
    }
    private void send() {
        String prompt = input.getText().trim(); if (prompt.isEmpty()) return;
        if (ClientPlayNetworking.canSend(ArgentNetworking.CHAT)) {
            PacketByteBuf buf = PacketByteBufs.create(); buf.writeString(prompt, 512); ClientPlayNetworking.send(ArgentNetworking.CHAT, buf);
            close();
        }
    }
    @Override public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        renderBackground(context); context.drawCenteredTextWithShadow(textRenderer, "ArgentAI - tell your companion what to build", width / 2, height / 2 - 42, 0xFFFFFF);
        super.render(context, mouseX, mouseY, delta);
    }
    @Override public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (keyCode == 257) { send(); return true; }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }
}
