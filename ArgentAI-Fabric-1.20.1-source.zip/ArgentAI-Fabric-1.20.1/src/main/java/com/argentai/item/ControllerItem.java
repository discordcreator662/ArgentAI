package com.argentai.item;

// Kept as a marker class for downstream integrations; the registered controller is a vanilla Item.
public final class ControllerItem { private ControllerItem() {} }
