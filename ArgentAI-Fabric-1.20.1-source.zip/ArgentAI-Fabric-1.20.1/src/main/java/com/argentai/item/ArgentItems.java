package com.argentai.item;

import com.argentai.ArgentAI;
import net.fabricmc.fabric.api.item.v1.FabricItemSettings;
import net.minecraft.item.Item;
import net.minecraft.item.SpawnEggItem;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;

public final class ArgentItems {
    public static final Item AI_CONTROLLER = new Item(new FabricItemSettings().maxCount(1));
    public static Item SPAWN_EGG;
    public static void register() {
        Registry.register(Registries.ITEM, new Identifier(ArgentAI.MOD_ID, "ai_controller"), AI_CONTROLLER);
        SPAWN_EGG = Registry.register(Registries.ITEM, new Identifier(ArgentAI.MOD_ID, "argentai_spawn_egg"),
            new SpawnEggItem(ArgentAI.ARGENT_ENTITY, 0xC8C8C8, 0x303030, new FabricItemSettings()));
    }
    private ArgentItems() {}
}
