package com.argentai.entity;

import net.minecraft.entity.EntityType;
import net.minecraft.entity.data.DataTracker;
import net.minecraft.entity.data.TrackedData;
import net.minecraft.entity.data.TrackedDataHandlerRegistry;
import net.minecraft.entity.ai.goal.LookAtEntityGoal;
import net.minecraft.entity.ai.goal.LookAroundGoal;
import net.minecraft.entity.ai.goal.SwimGoal;
import net.minecraft.entity.ai.goal.WanderAroundFarGoal;
import net.minecraft.entity.ai.goal.FollowOwnerGoal;
import net.minecraft.entity.mob.PathAwareEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.world.World;

public class ArgentEntity extends PathAwareEntity {
    private static final TrackedData<Boolean> ALEX_SKIN = DataTracker.registerData(ArgentEntity.class, TrackedDataHandlerRegistry.BOOLEAN);
    public ArgentEntity(EntityType<? extends PathAwareEntity> type, World world) { super(type, world); }
    @Override protected void initDataTracker() { super.initDataTracker(); dataTracker.startTracking(ALEX_SKIN, false); }
    public void setSkinStyle(String style) { dataTracker.set(ALEX_SKIN, style.equalsIgnoreCase("alex")); }
    public boolean isAlexSkin() { return dataTracker.get(ALEX_SKIN); }
    @Override protected void initGoals() {
        goalSelector.add(0, new SwimGoal(this));
        goalSelector.add(2, new LookAtEntityGoal(this, PlayerEntity.class, 8.0f));
        goalSelector.add(3, new WanderAroundFarGoal(this, 0.8));
        goalSelector.add(4, new LookAroundGoal(this));
    }
}
