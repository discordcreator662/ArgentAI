package com.argentai.network;

import com.argentai.ArgentAI;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

public final class ArgentNetworking {
    public static final Identifier CHAT = new Identifier(ArgentAI.MOD_ID, "chat");
    public static void registerServer() {
        ServerPlayNetworking.registerGlobalReceiver(CHAT, (server, player, handler, buf, responseSender) -> {
            String prompt = buf.readString(512);
            server.execute(() -> GroqService.ask(server, player, prompt));
        });
    }
    public static void tell(net.minecraft.entity.player.PlayerEntity player, String message) {
        player.sendMessage(Text.literal("[ArgentAI] " + message), false);
    }
    private ArgentNetworking() {}
}
