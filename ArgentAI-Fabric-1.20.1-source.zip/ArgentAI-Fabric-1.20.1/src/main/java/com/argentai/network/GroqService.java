package com.argentai.network;

import com.argentai.ArgentAI;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.registry.Registries;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;

public final class GroqService {
    private static final HttpClient HTTP = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(15)).build();
    private static final Path CONFIG = FabricLoader.getInstance().getConfigDir().resolve("argentai.json");
    private static String apiKey() throws IOException {
        if (!Files.exists(CONFIG)) {
            Files.createDirectories(CONFIG.getParent());
            JsonObject sample = new JsonObject(); sample.addProperty("apiKey", "PASTE_YOUR_NEW_GROQ_KEY_HERE"); sample.addProperty("model", "llama-3.3-70b-versatile");
            Files.writeString(CONFIG, sample.toString());
            throw new IOException("Created config/argentai.json. Add your Groq API key, then try again.");
        }
        return JsonParser.parseString(Files.readString(CONFIG)).getAsJsonObject().get("apiKey").getAsString();
    }
    public static void ask(MinecraftServer server, ServerPlayerEntity player, String prompt) {
        if (prompt.isBlank()) return;
        tell(player, "Thinking...");
        server.execute(() -> {});
        new Thread(() -> {
            try {
                String key = apiKey();
                JsonObject cfg = JsonParser.parseString(Files.readString(CONFIG)).getAsJsonObject();
                String model = cfg.has("model") ? cfg.get("model").getAsString() : "llama-3.3-70b-versatile";
                JsonObject body = new JsonObject(); body.addProperty("model", model); body.addProperty("temperature", 0.2);
                JsonArray messages = new JsonArray(); JsonObject sys = new JsonObject(); sys.addProperty("role", "system");
                sys.addProperty("content", "You are ArgentAI inside Minecraft Java 1.20.1. Reply ONLY as JSON: {\"message\":\"short response\",\"blocks\":[{\"x\":0,\"y\":0,\"z\":0,\"block\":\"minecraft:stone\"}]}. Coordinates are offsets from the player's current position. Use at most 128 blocks. Only use valid Minecraft block ids. If no building is requested, blocks must be empty. Never request dangerous actions."); messages.add(sys);
                JsonObject user = new JsonObject(); user.addProperty("role", "user"); user.addProperty("content", prompt); messages.add(user); body.add("messages", messages);
                HttpRequest req = HttpRequest.newBuilder(URI.create("https://api.groq.com/openai/v1/chat/completions")).timeout(Duration.ofSeconds(60)).header("Authorization", "Bearer " + key).header("Content-Type", "application/json").POST(HttpRequest.BodyPublishers.ofString(body.toString())).build();
                HttpResponse<String> res = HTTP.send(req, HttpResponse.BodyHandlers.ofString());
                if (res.statusCode() < 200 || res.statusCode() >= 300) throw new IOException("Groq returned HTTP " + res.statusCode() + ". Check your key/model.");
                JsonObject root = JsonParser.parseString(res.body()).getAsJsonObject();
                String content = root.getAsJsonArray("choices").get(0).getAsJsonObject().getAsJsonObject("message").get("content").getAsString();
                JsonObject answer = JsonParser.parseString(content).getAsJsonObject();
                String message = answer.has("message") ? answer.get("message").getAsString() : "Done.";
                JsonArray blocks = answer.has("blocks") ? answer.getAsJsonArray("blocks") : new JsonArray();
                server.execute(() -> {
                    if (player.isRemoved()) return;
                    tell(player, message);
                    int placed = 0;
                    for (var element : blocks) {
                        if (placed >= 128) break;
                        try {
                            JsonObject b = element.getAsJsonObject();
                            Identifier id = new Identifier(b.get("block").getAsString());
                            if (!Registries.BLOCK.containsId(id)) continue;
                            Block block = Registries.BLOCK.get(id);
                            int x = b.get("x").getAsInt(), y = b.get("y").getAsInt(), z = b.get("z").getAsInt();
                            if (Math.abs(x) > 16 || Math.abs(y) > 16 || Math.abs(z) > 16) continue;
                            BlockPos pos = player.getBlockPos().add(x, y, z);
                            if (player.getWorld().isInBuildLimit(pos) && player.getWorld().canPlayerModifyAt(player, pos)) {
                                BlockState state = block.getDefaultState();
                                if (player.getWorld().getBlockState(pos).isReplaceable()) { player.getWorld().setBlockState(pos, state, 3); placed++; }
                            }
                        } catch (Exception ignored) {}
                    }
                    if (placed > 0) tell(player, "Placed " + placed + " blocks.");
                });
            } catch (Exception e) { server.execute(() -> tell(player, "Error: " + e.getMessage())); ArgentAI.LOGGER.error("ArgentAI request failed", e); }
        }, "ArgentAI-Groq-Request").start();
    }
    private static void tell(ServerPlayerEntity player, String message) { ArgentNetworking.tell(player, message); }
    private GroqService() {}
}
