package com.argentai;

import com.argentai.command.ArgentCommands;
import com.argentai.entity.ArgentEntity;
import com.argentai.network.ArgentNetworking;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import com.argentai.item.ArgentItems;
import net.minecraft.item.ItemStack;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ArgentAI implements ModInitializer {
    public static final String MOD_ID = "argentai";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);
    public static EntityType<ArgentEntity> ARGENT_ENTITY;

    @Override public void onInitialize() {
        ARGENT_ENTITY = Registry.register(Registries.ENTITY_TYPE, new Identifier(MOD_ID, "argentai"),
            EntityType.Builder.create(ArgentEntity::new, SpawnGroup.CREATURE).dimensions(0.6f, 1.8f).maxTrackingRange(10).build("argentai"));
        ArgentItems.register();
        ArgentNetworking.registerServer();
        ArgentCommands.register();
        ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> {
            var player = handler.player;
            if (player.getCommandTags().add("argentai_starter_items")) {
                player.getInventory().insertStack(new ItemStack(ArgentItems.AI_CONTROLLER));
                player.getInventory().insertStack(new ItemStack(ArgentItems.SPAWN_EGG));
                player.sendMessage(net.minecraft.text.Text.literal("ArgentAI: Your controller and companion spawn egg are in your inventory."), false);
            }
        });
        ServerLifecycleEvents.SERVER_STARTED.register(server -> LOGGER.info("ArgentAI ready. Set your Groq key in config/argentai.json"));
        LOGGER.info("ArgentAI initialized");
    }
}
