package com.argentai.command;

import com.argentai.ArgentAI;
import com.argentai.entity.ArgentEntity;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.server.command.CommandManager;
import net.minecraft.text.Text;
import net.minecraft.util.math.Box;

public final class ArgentCommands {
    public static void register() {
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) ->
            dispatcher.register(CommandManager.literal("skin")
                .then(CommandManager.argument("style", StringArgumentType.word())
                    .suggests((ctx, builder) -> { builder.suggest("steve"); builder.suggest("alex"); return builder.buildFuture(); })
                    .executes(ctx -> {
                        String style = StringArgumentType.getString(ctx, "style");
                        if (!style.equalsIgnoreCase("steve") && !style.equalsIgnoreCase("alex")) { ctx.getSource().sendError(Text.literal("Usage: /skin <steve|alex>")); return 0; }
                        var player = ctx.getSource().getPlayer();
                        var entities = player.getWorld().getEntitiesByClass(ArgentEntity.class, new Box(player.getBlockPos()).expand(32), e -> true);
                        if (entities.isEmpty()) { ctx.getSource().sendError(Text.literal("Spawn ArgentAI with its spawn egg first.")); return 0; }
                        // Vanilla default skins are selected by UUID parity; set the entity UUID variant seed.
                        entities.get(0).setSkinStyle(style);
                        ctx.getSource().sendFeedback(() -> Text.literal("ArgentAI skin style set to " + style + "."), false);
                        return 1;
                    }))));
    }
    private ArgentCommands() {}
}
